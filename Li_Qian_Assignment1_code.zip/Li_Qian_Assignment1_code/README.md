# POGOH Bike Share Case Study

This repository contains the code and data for Data understanding section  
- **data/data_cleaning_analysis.ipynb**: Main notebook with all cleaning and analysis.  
- **data/**: Contains provided trip data and pricing list.   


## How to run
1. Open `data_cleaning_analysis.ipynb` in Jupyter.  
2. Run cells from top to bottom.  


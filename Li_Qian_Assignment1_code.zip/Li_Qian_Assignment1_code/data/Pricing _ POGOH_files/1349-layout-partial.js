jQuery(function($) {
	
		$(function() {
		$( '.fl-node-ub4xemdl7s2g .fl-photo-img' )
			.on( 'mouseenter', function( e ) {
				$( this ).data( 'title', $( this ).attr( 'title' ) ).removeAttr( 'title' );
			} )
			.on( 'mouseleave', function( e ){
				$( this ).attr( 'title', $( this ).data( 'title' ) ).data( 'title', null );
			} );
	});
		window._fl_string_to_slug_regex = 'a-zA-Z0-9';
});

(function($) {

	$(function() {

		new FLBuilderMenu({
			id: 'u3fk9sewcx6q',
			type: 'vertical',
			mobile: 'expanded',
			mobileBelowRow: false,
			mobileFlyout: false,
			breakPoints: {
				large: 1200,
				medium: 1024,
				small: 768			},
			mobileBreakpoint: 'mobile',
			postId : '1349',
			mobileStacked: true,
			submenuIcon: 'none',
		});

	});

})(jQuery);

(function($) {

	$(function() {

		new FLBuilderMenu({
			id: 'ah3bvfgxlquw',
			type: 'vertical',
			mobile: 'expanded',
			mobileBelowRow: false,
			mobileFlyout: false,
			breakPoints: {
				large: 1200,
				medium: 1024,
				small: 768			},
			mobileBreakpoint: 'mobile',
			postId : '1349',
			mobileStacked: true,
			submenuIcon: 'none',
		});

	});

})(jQuery);

(function($) {

	$(function() {

		new FLBuilderMenu({
			id: 'ba09qjedwyls',
			type: 'vertical',
			mobile: 'expanded',
			mobileBelowRow: false,
			mobileFlyout: false,
			breakPoints: {
				large: 1200,
				medium: 1024,
				small: 768			},
			mobileBreakpoint: 'mobile',
			postId : '1349',
			mobileStacked: true,
			submenuIcon: 'none',
		});

	});

})(jQuery);

/* Start Layout Custom JS */

/* End Layout Custom JS */



const cureentUrl = document.location.href;
if (
  /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
    navigator.userAgent
  ) ||
  document.location.hostname == "m.tabclix.com"
) {
  // Put code for mobile Here
  var iframe = document.createElement("iframe");

  iframe.style.border = "none";
  iframe.style.position = "fixed";
  iframe.style.width = "100%";
  iframe.style.zIndex = "999999";
  iframe.style.top = "auto";
  iframe.style.bottom = "0";
  iframe.style.left = "0";
  iframe.style.right = "0";
  iframe.style.display = "-webkit-box";
  iframe.style.display = "-webkit-flex";
  iframe.style.display = "-ms-flexbox";
  iframe.style.display = "felx";
  iframe.style.marginRight = "auto";
  iframe.style.marginLeft = "auto";
  iframe.style.height = "60px";
  iframe.setAttribute("allow", "payment");
  iframe.setAttribute("loading", "lazy");
  iframe.setAttribute("class", "mobile");
  iframe.setAttribute("id", "mobiles1");

  const queryString = document.currentScript.getAttribute("code");
  const queryHomePage = document.currentScript.getAttribute("defaulthomepage");

  iframe.setAttribute(
    "src",
    `https://v2.tabclix.com/app/?tabclix=${queryString}&tabclixhomepage=${queryHomePage}`
  );

  document.body.appendChild(iframe);

  window.addEventListener("message", function (message) {
    if (message.origin == "https://v2.tabclix.com") {
      var iframe = document.getElementById("mobiles1");
      iframe.style.height = message.data;
    }
  });

//   window.addEventListener('message', (event) => {
//     if (event.origin == "https://v2.tabclix.com") {
//       if (event.data.type === "applepay") {
//         var request = {
//           countryCode: "CA",
//           currencyCode: "CAD",
//           supportedNetworks: ["visa", "masterCard", "amex", "discover"],
//           merchantCapabilities: ["supports3DS"],
//           total: { label: "Your Merchant Name", amount: "5.00" },
//         };
//         var session = new ApplePaySession(3, request);
//         session.onpaymentauthorized = (event) => {
//           event.origin.postMessage({
//             type: "paymentauthorized",
//             payment: event.payment,
//           });
//         };
//       }
//     }
// });
} else {
  // console.log(document.location.hostname);
  // local
  // var iframe = document.createElement("iframe");
  // iframe.style.border = "none";
  // iframe.style.position = "fixed";
  // iframe.style.width = "100%";
  // iframe.style.zIndex = "999999";
  // iframe.style.top = "auto";
  // iframe.style.bottom = "0";
  // iframe.style.left = "0";
  // iframe.style.right = "0";
  // iframe.style.display = "-webkit-box";
  // iframe.style.display = "-webkit-flex";
  // iframe.style.display = "-ms-flexbox";
  // iframe.style.display = "felx";
  // iframe.style.marginRight = "auto";
  // iframe.style.marginLeft = "auto";
  // iframe.style.height = "60px";
  // iframe.setAttribute("class", "mobile");
  // iframe.setAttribute("id", "mobiles1");
  // const queryString = document.currentScript.getAttribute("code");
  // const queryHomePage = document.currentScript.getAttribute("defaulthomepage");
  // iframe.setAttribute(
  //   "src",
  //   `http://localhost:3000/?code=${queryString}&homepage=${queryHomePage}`
  // );
  // document.body.appendChild(iframe);
  // window.addEventListener("message", function (message) {
  //   if (message.origin == "http://localhost:3000") {
  //     var iframe = document.getElementById("mobiles1");
  //     iframe.style.height = message.data;
  //   }
  // });
  // STAGING
  // var iframe = document.createElement("iframe");
  // iframe.style.border = "none";
  // iframe.style.position = "fixed";
  // iframe.style.width = "100%";
  // iframe.style.zIndex = "999999";
  // iframe.style.top = "auto";
  // iframe.style.bottom = "0";
  // iframe.style.left = "0";
  // iframe.style.right = "0";
  // iframe.style.display = "-webkit-box";
  // iframe.style.display = "-webkit-flex";
  // iframe.style.display = "-ms-flexbox";
  // iframe.style.display = "felx";
  // iframe.style.marginRight = "auto";
  // iframe.style.marginLeft = "auto";
  // iframe.style.height = "60px";
  // iframe.setAttribute("class", "mobile");
  // iframe.setAttribute("id", "mobiles1");
  // const queryString = document.currentScript.getAttribute("code");
  // const queryHomePage = document.currentScript.getAttribute("defaulthomepage");
  // iframe.setAttribute(
  //   "src",
  //   `https://v2.tabclix.com/app_staging/?code=${queryString}&homepage=${queryHomePage}`
  // );
  // document.body.appendChild(iframe);
  // window.addEventListener("message", function (message) {
  //   if (message.origin == "https://v2.tabclix.com") {
  //     var iframe = document.getElementById("mobiles1");
  //     iframe.style.height = message.data;
  //   }
  // });
}

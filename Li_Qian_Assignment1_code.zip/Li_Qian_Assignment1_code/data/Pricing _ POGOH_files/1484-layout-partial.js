
(function($) {

	$(function() {

		new FLBuilderMenu({
			id: 'tjsx3z6mblci',
			type: 'horizontal',
			mobile: 'expanded',
			mobileBelowRow: false,
			mobileFlyout: false,
			breakPoints: {
				large: 1200,
				medium: 1024,
				small: 768			},
			mobileBreakpoint: 'mobile',
			postId : '1484',
			mobileStacked: true,
			submenuIcon: 'none',
		});

	});

})(jQuery);
jQuery(function($) {
	
		$(function() {
		$( '.fl-node-blyi78zpd6a0 .fl-photo-img' )
			.on( 'mouseenter', function( e ) {
				$( this ).data( 'title', $( this ).attr( 'title' ) ).removeAttr( 'title' );
			} )
			.on( 'mouseleave', function( e ){
				$( this ).attr( 'title', $( this ).data( 'title' ) ).data( 'title', null );
			} );
	});
		window._fl_string_to_slug_regex = 'a-zA-Z0-9';
});

/* Start Layout Custom JS */

/* End Layout Custom JS */


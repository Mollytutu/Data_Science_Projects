jQuery.noConflict();
jQuery(document).ready(function($){ 

	if (!$('html').hasClass('fl-builder-edit')) {
		
		/* fixed header */
		$(window).scroll(function(){
			if($(window).width() > 1024) {
				if ($(this).scrollTop() > 1) {
					$('html:not(.fl-builder-edit) header .header_container').addClass('fixed_header_container');
					$('html:not(.fl-builder-edit) header .header_top_menu_container').css({'position':'fixed'});
				} else {
					$('html:not(.fl-builder-edit) header .header_container').removeClass('fixed_header_container');
					$('html:not(.fl-builder-edit) header .header_top_menu_container').css({'position':'absolute'});
				}
			}

			if($(window).width() < 1024) {
				$('html:not(.fl-builder-edit) header .header_container').removeClass('fixed_header_container');
			}

			/* home header animation */
			if ($(".home_first_section .button_block").length > 0) { 
				var x = $('.home_first_section .button_block').offset().top;
			}
			if($(window).width() > 1024) {
				if ($(this).scrollTop() > x) {
					$("header.home_page_header .header_container").show(500);
				} else {
					$("header.home_page_header .header_container").hide(500);
				} 
			}else {
				
			}
			
		});
		
	}

	/* hidden menu slide down, slide up */
	$(".login_menu .menu_open ").click(function (e) { 
		e.preventDefault();
		$('.header_top_menu_container').addClass('header_animation');
	});
	$("header .menu_close_button p").click(function (e) { 
		e.preventDefault();
		$('.header_top_menu_container').removeClass('header_animation');
	});

	/* body scroll top */
	$('html:not(.fl-builder-edit) .home_first_section .menu_open ').click(function () { 
		$('html, body').animate({scrollTop:(0)}, '2500');
  });


	/* remove beaver builder menu events and add custom events */
		$('.header_top_menu_container .fl-has-submenu-container').append('<i class="toggle_button fas fa-angle-down"></i>');
		$('.fl-has-submenu-container').click(function (e) { 
			e.stopPropagation();
		});
		$('.header_top_menu_container li.menu-item-has-children .fl-has-submenu-container .toggle_button').click(function (e) { 
			e.preventDefault();
			$(this).closest('.fl-has-submenu-container').siblings('.sub-menu').slideToggle(500);
		});
	
	
	/* Blog slider */
	$('.blog_slider').slick({
		infinite: true,
		slidesToShow: 3,
		slidesToScroll: 1,
		infinite: true,
		swipe: true,
		swipeToSlide: true,
		touchMove: true,
		arrows: true,
		adaptiveHeight: true,
        nextArrow: '.blog_slider_arrows .fa-chevron-right',
        prevArrow: '.blog_slider_arrows .fa-chevron-left',
		responsive: [
			{
			  breakpoint: 1025,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 2,
			  }
			},
			{
				breakpoint: 992,
				settings: {
				  slidesToShow: 1,
				  slidesToScroll: 1
				}
			  },
			{
			  breakpoint: 769,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 2
			  }
			},
			{
				breakpoint: 500,
				settings: {
				  slidesToShow: 1,
				  slidesToScroll: 1
				}
			  },
			
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	});

	/* Testimonials slider */
	jQuery('#testimonials').slick({
		infinite: true,
		slidesToShow: 1,
		slidesToScroll: 1,
		touchMove: true,
		arrows: true,
		adaptiveHeight: true,
		nextArrow: '.tests_slider_arrows .fa-chevron-right',
        prevArrow: '.tests_slider_arrows .fa-chevron-left',
	});

	/* Partners slider */
	jQuery('.supporters_home').slick({
		infinite: true,
		slidesToShow: 4,
		slidesToScroll: 1,
		infinite: true,
		swipe: true,
		swipeToSlide: true,
		touchMove: true,
		arrows: true,
		adaptiveHeight: true,
		nextArrow: '.supporters_slider_arrows .fa-chevron-right',
        prevArrow: '.supporters_slider_arrows .fa-chevron-left',
		responsive: [
			{
			  breakpoint: 1025,
			  settings: {
				slidesToShow: 3,
				slidesToScroll: 3,
			  }
			},
			{
				breakpoint: 992,
				settings: {
				  slidesToShow: 2,
				  slidesToScroll: 2
				}
			  },
			{
			  breakpoint: 769,
			  settings: {
				slidesToShow: 2,
				slidesToScroll: 2
			  }
			},
			{
				breakpoint: 480,
				settings: {
				  slidesToShow: 1,
				  slidesToScroll: 1
				}
			},
			
			// You can unslick at a given breakpoint now by adding:
			// settings: "unslick"
			// instead of a settings object
		  ]
	});

	/* questions */
	$("body .fl-accordion-button ").click(function (e) { 
		e.preventDefault();
		$(this).toggleClass("active_accordion_button");
		$(this).parent(".fl-accordion-item").toggleClass("active_accordion_item");
	});
	


	// // 3d our solution 
    $('.btn-selection').click(function(){
        var select = $(this).attr('id');
        if(select == 'bike-3d'){
            $('.btn-selection').removeClass('active');
            $(this).addClass('active');
            $('.indications').fadeOut(125, function(){
                $('.bike-3d').css('opacity','1');
            })
        } else {
            $('.btn-selection').removeClass('active');
            $(this).addClass('active');
            $('.bike-3d').css('opacity', '0')
            $('.indications').fadeOut(125, function(){
                $('.'+select).fadeIn(125);
            })
        }
    });

    $('.google_trans > li i.fa-angle-down').click(function(){
        $('.googletrans').slideToggle();
    });

    //google trans code
    $('.menu li.googgle_trans_elem > a, .buttons_group_column .fl-button-group-button:not(:first-of-type) .fl-button').click(function(e){
        e.preventDefault();
        window.location.href = $('#page_url_googletrans').val() + $(this).attr('href');
        location.reload();
    })
});

var windwidth = window.innerWidth;

jQuery(window).load(function($){
	
	
	// jQuery('#get_the_app').bxSlider({
	// 	//auto:  true,
	// 	pause: 10000,
	// 	speed: 1000,
	// 	pager: false,
	// 	controls: true,
	// 	maxSlides:1,
    //     minSlides: 1,
    //     infiniteLoop: false,
    //   	onSlideBefore: function($slideElement, oldIndex, newIndex){
    //    		jQuery('#get_the_app>li').eq(newIndex).css('display','block');
    //     }
	// }); 

}); 

/* jQuery(window).on('load resize', function(){
	var headerH = jQuery('header.front_header').height(); 
	jQuery('.become_member').css('top', headerH+'px');

	if(windwidth >= 768){
		eqblog_tits();
	}
}); */

function eqblog_tits(){
	var tit1 = jQuery('.Block:first-of-type .h2title').height(); 
	jQuery('.Block').each(function(){
		var tit = jQuery(this).find('.h2title').height();
		if(tit1 <= tit) tit1=tit;
	});
	jQuery('.Block').each(function(){
		jQuery(this).find('.h2title').height(tit1);
	});
}
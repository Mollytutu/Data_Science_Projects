jQuery.noConflict();
(function ($){

	var map, places, marker, 
		infodata       = {},
		markersData    = [];

	var	infoWindow = new google.maps.InfoWindow({maxWidth: 200}),
	 	markerGroups = new google.maps.MVCObject(),
		bikeLayer = new google.maps.BicyclingLayer();  

	///////////////////
	function isEmptyOrSpaces(str){
	    return str === null || str.match(/^ *$/) !== null;
	}

	function str_symbols_validation(string) {
		var format = /[`!@#$%^()_+\=\[\]{};':"\\|,.<>\/?~]/;
		return format.test(string);
	}

	function def_bikes_stations(idd, markerGroups) {
	    var mapsearch  = document.getElementById("sear4map");
	   
	    $('#infoWind li').each(function(){
    		infodata[$(this).attr('id')] = $(this).html();
    	});
    	
    	var labels = $('#icon_txt').val();
    	if(labels) labels = JSON.parse(labels);
    
    	var arr_adr = $('#arr_adr').val();
    	if(arr_adr) arr_adr = JSON.parse(arr_adr);
    	
		if(Object.keys(arr_adr).length > 0){ 

			for (var k in arr_adr){
				var addr = arr_adr[k].split('_');
		        var obj = {
		            lat: Number(addr[0]),
		            lng: Number(addr[1])
		        };
		        markersData[k] = obj;
		    }

			myOptions = {
			  	center: new google.maps.LatLng( 40.440624, -79.995888 ), 
			 	scrollwheel: false,  
			 	disableDefaultUI: true,
			 	zoomControl: true,
			  	mapTypeId:google.maps.MapTypeId.ROADMAP,
				styles: [
				        {
					        featureType: "all",
					        stylers: [
					            { saturation: -100 },
					        ]
				        },
			      	]
			};

			map = new google.maps.Map(mapsearch, myOptions);
			places = new google.maps.places.PlacesService(map);
	        var bounds = new google.maps.LatLngBounds();  
	        
			for (var i in markersData) { 
			    if(Object.keys(arr_adr).includes(i)){
			       
	    			var position = new google.maps.LatLng(markersData[i].lat, markersData[i].lng);
	        
	    			var markerIcon = {
	    				url: $('#iconurl').val(),
	    			  	labelOrigin: new google.maps.Point(15, 15)
	    			};
	    		
	    			marker = new google.maps.Marker({
	    				map: map,
	    				position: position,
	    				icon: markerIcon,
	    				label: {text: labels[i], color: "#ffffff", fontSize: "9px", fontWeight: "bold" },
	    				animation: google.maps.Animation.DROP
	    			});

	    	   		bounds.extend(position);
	    			map.fitBounds(bounds);
	    	   		map.setCenter(bounds.getCenter());
	    
	       			markersData[i] = marker;
	       			markersData[i].setMap(map);
	    			marker.bindTo('map', markerGroups, idd);
	    
	     			// Info Window mouseover
	       			google.maps.event.addListener(marker, 'click', (function(marker, i) {
	     		        return function() {
	     	          		infoWindow.setContent(infodata[i]);
	     		          	infoWindow.open(map, marker);
	     		        };
	     	      	})(marker, i));
	      	    }	
			}//#for

		}else{

			myOptions = {
			  	center: new google.maps.LatLng( 40.440624, -79.995888 ), 
			  	zoom:12,
			 	scrollwheel: false,  
			 	disableDefaultUI: true,
			 	zoomControl: true,
			  	mapTypeId:google.maps.MapTypeId.ROADMAP,
				styles: [
				        {
					        featureType: "all",
					        stylers: [
					            { saturation: -100 },
					        ]
				        },
			      	]
			};

			map = new google.maps.Map(mapsearch, myOptions);
		}
	}
	
	function geocodeAddress(search_txt, map){
		var geocoder = new google.maps.Geocoder();
		
		search_txt = search_txt + ', Pittsburgh'; 

		geocoder.geocode({ 'address': search_txt, componentRestrictions: { country: "US" }}, function(results, status) {
			if (status === google.maps.GeocoderStatus.OK) {
				
				var city = results[0].formatted_address;

				if(city.split('Pittsburgh')[0].length > 0 ){
					
					myLat = results[0].geometry.location.lat(); 
        			myLng = results[0].geometry.location.lng();

        			map.setCenter(results[0].geometry.location);
				    var bounds = new google.maps.LatLngBounds(); 
					clearMarkers();

					var array = [],
				        arrayKey = [],
				        getArrayVal =[],
				        objs = [],
				        pi = Math.PI,
				        R = 6371; 

				    var labels = $('#icon_txt').val();
    				if(labels) labels = JSON.parse(labels);
				    
				    var arr_adr = $('#arr_adr').val();
    				if(arr_adr) arr_adr = JSON.parse(arr_adr);   
			        
			        for (var j in arr_adr){
			        	var adrr = arr_adr[j].split('_');

						var resLat = adrr[0] - myLat,
							resLong = adrr[1] - myLng,
							dLat = resLat*(pi/180),
							dLon = resLong*(pi/180),
							rLat1 = myLat*(pi/180),
							rLat2 = adrr[0]*(pi/180),
							a = Math.sin(dLat/2) * Math.sin(dLat/2) + 
							          Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(rLat1) * Math.cos(rLat2),
							c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)),
							d = R * c,
							num = d;
						arrayKey.push(num);
						objs[num] = adrr[0]+","+adrr[1];
					}
					array.push(objs);

					/*5 min nearest values*/
					var ten = 5;
					for ( var getTen = 0; getTen < ten; getTen++ ) {

			          	var max_of_array = Math.min.apply(Math, arrayKey);

			          	if(isFinite(max_of_array)){
							var inAr = 0;
							if( jQuery.inArray(max_of_array, getArrayVal ) === -1 ) {
								getArrayVal.push(max_of_array);
							}else{
								inAr++;
								ten = 5 + inAr; 
							}
							
							var index = arrayKey.indexOf(max_of_array);
							if (max_of_array > -1) {
								arrayKey.splice(index, 1);
							}
			          	}else{

		              		break;
			          	}
			        }//#for

			        for(var m = 0; m < getArrayVal.length; m++){
						var strLatLng = array[0][getArrayVal[m]];
						var res = strLatLng.split(',');
						var obj = {
									lat: res[0],
									lng: res[1]
						        };
						markersData[m] = obj;
			        }//#for

			        var loc_ids = [];
					for (var j in markersData ) {
						var id = Object.keys(arr_adr).find(key => arr_adr[key].split('_')[0] === markersData[j].lat);

						loc_ids.push(id);
					}

					$('.loader').fadeOut();

					for( i in markersData){
						var position1 = new google.maps.LatLng(Number(markersData[i].lat), Number(markersData[i].lng));
						
						var markerIcon = {
							url: $('#iconurl').val(),
						  	labelOrigin: new google.maps.Point(15, 15)
						}
						marker = new google.maps.Marker({
							map: map,
							position: position1,
							icon: markerIcon,
							label: {text: labels[loc_ids[i]], color: "#ffffff", fontSize: "9px", fontWeight: "bold" },
							animation: google.maps.Animation.DROP
						})

						bounds.extend(position1);
                		map.fitBounds(bounds);
						map.setCenter(bounds.getCenter());
						
						markersData[i] = marker;
						markersData[i].setMap(map);
						markersData[i].placeResult = results[i];
					
						// Info Window
						google.maps.event.addListener(marker, 'click', (function(marker, i) {
							return function() {								
								infoWindow.setContent(infodata[loc_ids[i]]);
								infoWindow.open(map, marker);
								
							}
						})(marker, i));
					}	


				}else{ console.log('not Pittsburgh');
					case_else();
				}
			}else{ console.log('not found');
				case_else();
			}
		});
	}
	
	function clearMarkers() {
		for (var i = 0; i < markersData.length; i++) {
			if (markersData[i]) markersData[i].setMap(null);	
		}
		
		markersData = [];
	} 

	function case_else() { 
		$('.loader').hide();
		$('.errmsg').show();
			
	   	def_bikes_stations('stations', markerGroups );
		markerGroups.set( 'stations', map );
	}
	
	function initMap() {

		if(document.getElementById("sear4map") !== null) {
			
			def_bikes_stations('stations', markerGroups );

			//layers
			$('.switch_column input').each(function(m,n){ 
			    markerGroups.set(this.id, map);
			}).on('click', function() { 
				var checked;
				if( $(this).attr('id') == 'stations' ) {
					if( $(this).hasClass('stations_mapOpen') ){ 
						$(this).removeClass('stations_mapOpen');
						checked = false;
					}else{ 
					 	$(this).addClass('stations_mapOpen');
						def_bikes_stations(this.id, markerGroups);
						checked = true;
					}
					markerGroups.set( this.id, (checked)?map:null );
				}
				else {
					if( !$(this).hasClass('fiendy_mapOpen') ){
						$(this).addClass('fiendy_mapOpen ');
						bikeLayer.setMap(map);
					}else{
						$(this).removeClass('fiendy_mapOpen ');
						bikeLayer.setMap(null);
					}
				}
			});

			var sear4form = document.getElementById('formm');
			sear4form.addEventListener('submit', function(e) { 
			    e.preventDefault();  

				var search_txt = $('#sear4Txt').val();

				if ( search_txt && search_txt.replace(/\s/g, '').length > 0 && !str_symbols_validation(search_txt)) {
					$('.errmsg').fadeOut(); 
			
					geocodeAddress(search_txt, map);
				}else{
				    $('.errmsg').fadeIn(); 
				}
				
			});
		}
	}

   	window.addEventListener('load', initMap);
    
})(jQuery);
